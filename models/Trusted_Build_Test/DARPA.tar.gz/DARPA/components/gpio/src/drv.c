/*
 * The contents of this package are proprietary to National ICT Australia Limited
 * (NICTA), ABN 62 102 206 173 and you may not use, copy, modify, sublicense or
 * distribute the contents in any form except as permitted under the terms of a
 * separately executed license agreement with NICTA, such as (if applicable to
 * you) one of the following:
 *
 * 1. SMACCM Project License Agreement (Technical Area 4), by and between NICTA and Rockwell Collins, effective 29 January 2013.
 * 2. SMACCM Project Licence Agreement (Technical Area 4), by and between NICTA and Regents of the University of Minnesota, effective 5 April 2013.
 * 3. SMACCM Project Licence Agreement (Technical Area 3), by and between NICTA and Galois, Inc., effective 21 February 2013.
 */

#include <platsupport/mux.h>
#include <platsupport/gpio.h>

#include "utils.h"

#include "gpio.h"

mux_sys_t exynos_mux;
gpio_sys_t gpio_sys;
gpio_t gpio;

void gpio__init(void) {

	exynos_mux_init(gpio1base, gpio2base, NULL, NULL, &exynos_mux);

	/* Enable UART0, UART3 and SPI0. */
	mux_feature_enable(&exynos_mux, MUX_UART0);
	mux_feature_enable(&exynos_mux, MUX_UART1);
	mux_feature_enable(&exynos_mux, MUX_UART3);
	mux_feature_enable(&exynos_mux, MUX_SPI1);

	exynos_gpio_sys_init(&exynos_mux, &gpio_sys);
	gpio_new(&gpio_sys, GPX2, 0, GPIO_DIR_OUT, &gpio);
	gpio_set(&gpio);
}

int gpio_mmc_config(int peripheral, int flags)
{
	/* TODO: To be moved to libplatsupport. */
}

int gpio_pinmux_config(int peripheral, int flags)
{
	char *buf = (char*)gpio1base;

	if (flags) {
		gpio_clr(&gpio);
	} else {
		gpio_set(&gpio);
	}
}

int run(void)
{
	gpio_t gpio_int;
	gpio_new(&gpio_sys, GPX1, 7, GPIO_DIR_IN, &gpio_int);

	while (1) {
		if (!gpio_get(&gpio_int)) {
			printf("Int fired...\n");
		}
	}
}
