/*
 * The contents of this package are proprietary to National ICT Australia Limited
 * (NICTA), ABN 62 102 206 173 and you may not use, copy, modify, sublicense or
 * distribute the contents in any form except as permitted under the terms of a
 * separately executed license agreement with NICTA, such as (if applicable to
 * you) one of the following:
 *
 * 1. SMACCM Project License Agreement (Technical Area 4), by and between NICTA and Rockwell Collins, effective 29 January 2013.
 * 2. SMACCM Project Licence Agreement (Technical Area 4), by and between NICTA and Regents of the University of Minnesota, effective 5 April 2013.
 * 3. SMACCM Project Licence Agreement (Technical Area 3), by and between NICTA and Galois, Inc., effective 21 February 2013.
 */

/* standard */
#include <stdio.h>
#include <string.h>

#include "client.h"

/* application common */
#include "common.h"

int run(void)
{
	char str[] = "UART Test\n";
	int i = 0;
	int len = 12;
	int error = 0;

	/*
	 * Timer test
	 */
	unsigned int cnt = 1;

	printf("Start UART Test\n");
	char* buf = (char*) uart_buf;
	int rcount = 0;
	int wcount = 0;
	strcpy(buf,str);
	wcount = uart_write(0, 15);
	while(1){
		uart_read(0,10);
		printf("read: %s\n",buf);
		uart_write(0,10);
	}

	printf("finish\n");
}

