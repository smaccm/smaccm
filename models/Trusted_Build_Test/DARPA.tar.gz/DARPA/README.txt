The contents of this package are proprietary to National ICT Australia Limited
(NICTA), ABN 62 102 206 173 and you may not use, copy, modify, sublicense or
distribute the contents in any form except as permitted under the terms of a
separately executed license agreement with NICTA, such as (if applicable to
you) one of the following:

1. SMACCM Project License Agreement (Technical Area 4), by and between NICTA and Rockwell Collins, effective 29 January 2013.
2. SMACCM Project Licence Agreement (Technical Area 4), by and between NICTA and Regents of the University of Minnesota, effective 5 April 2013.
3. SMACCM Project Licence Agreement (Technical Area 3), by and between NICTA and Galois, Inc., effective 21 February 2013.

This directory contains the sources for SMACCM milestone 4.1.2.4.3 "Deliver
final implementation of seL4-based device drivers for FLASH and CAN bus
controller and other devices needed for Rev1 open source vehicle" for delivery
to the government.

The sources include fully implemented drivers for the FLASH, CAN, SPI, UART,
GPIO, and PLL devices on the Samsung Exynos 5 board, implemented as CAmkES
components running on top of seL4.
