/*
 * The contents of this package are proprietary to National ICT Australia Limited
 * (NICTA), ABN 62 102 206 173 and you may not use, copy, modify, sublicense or
 * distribute the contents in any form except as permitted under the terms of a
 * separately executed license agreement with NICTA, such as (if applicable to
 * you) one of the following:
 *
 * 1. SMACCM Project License Agreement (Technical Area 4), by and between NICTA and Rockwell Collins, effective 29 January 2013.
 * 2. SMACCM Project Licence Agreement (Technical Area 4), by and between NICTA and Regents of the University of Minnesota, effective 5 April 2013.
 * 3. SMACCM Project Licence Agreement (Technical Area 3), by and between NICTA and Galois, Inc., effective 21 February 2013.
 */

/*
 * device.h
 * device structure for applications
 *
 *  Created on: Aug 23, 2013
 *      Author: jxie
 */

#ifndef DEVICE_H_
#define DEVICE_H_


struct timer{
	uint32_t id;
};






#endif /* DEVICE_H_ */
