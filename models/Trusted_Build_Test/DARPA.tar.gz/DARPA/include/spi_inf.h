/*
 * The contents of this package are proprietary to National ICT Australia Limited
 * (NICTA), ABN 62 102 206 173 and you may not use, copy, modify, sublicense or
 * distribute the contents in any form except as permitted under the terms of a
 * separately executed license agreement with NICTA, such as (if applicable to
 * you) one of the following:
 *
 * 1. SMACCM Project License Agreement (Technical Area 4), by and between NICTA and Rockwell Collins, effective 29 January 2013.
 * 2. SMACCM Project Licence Agreement (Technical Area 4), by and between NICTA and Regents of the University of Minnesota, effective 5 April 2013.
 * 3. SMACCM Project Licence Agreement (Technical Area 3), by and between NICTA and Galois, Inc., effective 21 February 2013.
 */

/*
 * spi external interfaces
 */

#ifndef SPI_INF_H
#define SPI_INF_H

#include <stdbool.h>

#define SPI_TRANS_MAX_SIZE	255
typedef struct spi_buf_t{
	uint8_t txbuf[SPI_TRANS_MAX_SIZE];
	uint8_t rxbuf[SPI_TRANS_MAX_SIZE];
	volatile bool lock;					//shared buffer lock
}spi_dev_port, *spi_dev_port_p;



#endif
