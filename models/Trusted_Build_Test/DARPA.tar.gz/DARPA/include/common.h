/*
 * The contents of this package are proprietary to National ICT Australia Limited
 * (NICTA), ABN 62 102 206 173 and you may not use, copy, modify, sublicense or
 * distribute the contents in any form except as permitted under the terms of a
 * separately executed license agreement with NICTA, such as (if applicable to
 * you) one of the following:
 *
 * 1. SMACCM Project License Agreement (Technical Area 4), by and between NICTA and Rockwell Collins, effective 29 January 2013.
 * 2. SMACCM Project Licence Agreement (Technical Area 4), by and between NICTA and Regents of the University of Minnesota, effective 5 April 2013.
 * 3. SMACCM Project Licence Agreement (Technical Area 3), by and between NICTA and Galois, Inc., effective 21 February 2013.
 */

#ifndef COMMON_H
#define COMMON_H

/* Application IDs*/
#define CLIENT_APP_ID	0
#define CAN_APP_ID		1
#define NUM_APPS		2

/* Generic Constants */
#define TRUE 	1
#define FALSE	0

typedef enum{
	CLEAR 		= 2,
	ENABLE 		= 1,
	DISABLE 	= 0
}OPTION;

#define ROUND(a,b)		(((a) + (b) - 1) & ~((b) - 1))
#define DIV_ROUND(n,d)		(((n) + ((d)/2)) / (d))
#define DIV_ROUND_UP(n,d)	(((n) + (d) - 1) / (d))
#define roundup(x, y)		((((x) + ((y) - 1)) / (y)) * (y))

/**
 * container_of - cast a member of a structure out to the containing structure
 * @ptr:	the pointer to the member.
 * @type:	the type of the container struct this is embedded in.
 * @member:	the name of the member within the struct.
 *
 */
#define container_of(ptr, type, member) ({			\
	const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
	(type *)( (char *)__mptr - offsetof(type,member) );})

#endif
