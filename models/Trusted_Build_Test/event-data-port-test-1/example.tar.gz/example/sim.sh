#/bin/sh
qemu-system-arm -machine simple-armv7m -kernel ./out/kochab-system/system -s -S -semihosting
