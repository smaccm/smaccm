/*
Unpublished copyright (c) 2013 National ICT Australia (NICTA),
ABN 62 102 206 173.  All rights reserved.

The contents of this document are proprietary to NICTA and you may not
use, copy, modify, sublicense or distribute the contents in any form
except as permitted under the terms of a separately executed licence
agreement with NICTA.

COMMERCIAL LICENSE RIGHTS
Agreement No.: FA8750-12-9-0179
Contractor's Name; Rockwell Collins, Inc.
Contractor's Address: 400 Collins Road N.E., Cedar Rapids, IA 52498

By accepting delivery of the RTOS Code and Documentation, the Licensee
agrees that the software is "commercial" computer software within the
meaning of the applicable acquisition regulations (e.g., FAR 2.101 or
DFARS 227.7202-3).  The terms and conditions of this License shall pertain
to the Licensee's use and disclosure of the software, and shall supersede
any conflicting contractual terms or conditions.

*/
#include "rtos-kochab.h"
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

#include "bitband.h"



#define TASK_ID_NONE ((TaskIdOption) TASK_ID_C(UINT8_MAX))

#define CONTEXT_SIZE 10
#define CONTEXT_V1_IDX 0
#define CONTEXT_V2_IDX 1
#define CONTEXT_V3_IDX 2
#define CONTEXT_V4_IDX 3
#define CONTEXT_V5_IDX 4
#define CONTEXT_V6_IDX 5
#define CONTEXT_V7_IDX 6
#define CONTEXT_V8_IDX 7
#define CONTEXT_IP_IDX 8
#define CONTEXT_PC_IDX 9
#define SCHED_INDEX_ZERO ((SchedIndex) TASK_ID_ZERO)
/* Sanity check; should be impossible (since there is no uint256_t!) */
#if 8 > UINT8_MAX
#  error "signalset_size (8) is greater than UINT8_MAX"
#endif


#define MUTEX_ID_NONE ((MutexIdOption) UINT8_MAX)
#define SEM_ID_NONE ((SemIdOption) SEM_ID_C(UINT8_MAX))
#define SEM_ID_ZERO SEM_ID_C(0)
#define SEM_ID_MAX SEM_ID_C(0)
#define SEM_VALUE_ZERO ((SemValue) UINT8_C(0))
typedef TaskId TaskIdOption;
typedef uint32_t* context_t;
typedef TaskId SchedIndex;
typedef MutexId MutexIdOption;
typedef uint8_t SemValue;
typedef SemId SemIdOption;
struct task
{
    context_t ctx;
};

struct irq_event_handler {
    TaskId task;
    SignalSet sig_set;
};


struct sched_task {
    TaskIdOption blocked_on;
};

/*
 * NOTE: An RTOS variant using the scheduler must ensure that tasks
 * array is sorted by priority.
 */
struct sched {
    struct sched_task tasks[2];
};
struct signal_task {
    SignalSet signals;
};

struct signal {
    struct signal_task tasks[2];
};



struct mutex {
    TaskIdOption holder;
};

struct semaphore {
    SemValue value;
};
extern void fn_b(void);
extern void fn_a(void);
extern volatile uint8_t exception_preempt_disabled;
extern volatile uint8_t exception_preempt_pending;

extern void armv7m_context_switch(context_t *, context_t *);
extern void armv7m_context_switch_first(context_t *);
extern void armv7m_trampoline(void);






static void _yield(void);
static void _block(void);
static void _unblock(TaskId task);
static void handle_irq_event(IrqEventId irq_event_id);
static void _preempt_enable(void);

/**
 * Set up the initial execution context of a task.
 * This function is invoked exactly once for each task in the system.
  *
 * @param ctx An output parameter interpreted by the RTOS as the initial context for each task.
 *  After this function returns, the RTOS uses the value of ctx for task/context/stack switching.
 *  The concept of a context and of the context_t type is abstract and may have different implementations on
 *  different platforms.
 *  It can be, e.g., a stack pointer or a data structure for user-level task switching as on POSIX.
 *  This function is expected to set ctx to a value that the RTOS can pass to this platform's implementation of
 *  context_switch() and context_switch_first().
 *  The context must be set up such that the destination task of a task switch executes the code at the address fn
 *  using the memory region defined by stack_base and stack_size as its stack.
 *  For hardware platforms, this typically requires the following set up steps:
 *  - The value of ctx points to either the beginning or the end of the stack area.
 *  - The stack area contains fn so that the context-switch functions can pop it off the stack as a return address to
 *    begin execution at.
 *  - Optionally reserve additional stack space if the context-switch functions depend on it.
 * @param fn Points to a code address at which the given execution context shall start executing.
 *  This is typically a pointer to a parameter-less function that is assumed to never return.
 * @param stack_base Points to the lowest address of the memory area this execution context shall use as a stack.
 * @param stack_size The size in bytes of the stack memory area reserved for this execution context.
 */
static void context_init(context_t *const ctx, void (*const fn)(void), uint32_t *const stack_base, const size_t stack_size);
static void sched_set_runnable(const TaskId task_id);
static void sched_set_blocked(const TaskId task_id);
static void sched_set_blocked_on(const TaskId task_id, const TaskId blocker);
static TaskIdOption sched_get_next(void);
static SignalId _signal_recv(SignalSet *const cur_task_signals, const SignalSet mask);
static void irq_event_process(void);
static inline bool irq_event_check(void);
static inline void irq_event_wait(void);
static TaskId irq_event_get_next(void);

static bool internal_sem_try_wait(const SemId s);
static TaskId current_task;
static struct task tasks[2];

struct irq_event_handler irq_events[1] = {
 { 0, SIGNAL_SET_IRQ_TICK },
};
static uint32_t stack_0[64] __attribute__((aligned(8)));
static uint32_t stack_1[64] __attribute__((aligned(8)));

static struct sched sched_tasks;
static struct signal signal_tasks;
VOLATILE_BITBAND_VAR(uint32_t, irq_event);

static struct mutex mutexes[1];
static MutexIdOption waiters[2];
static struct semaphore semaphores[0];
static SemIdOption waiters[2];
#define preempt_disable() exception_preempt_disabled = 1
#define preempt_enable() _preempt_enable()
#define get_current_task() current_task
#define get_task_context(task_id) &tasks[task_id].ctx
#define irq_event_id_to_taskid(irq_event_id) ((TaskId)(irq_event_id))

#define context_switch(from, to) armv7m_context_switch(to, from)
#define context_switch_first(to) armv7m_context_switch_first(to)
#define sched_runnable(task_id) (SCHED_OBJ(task_id).runnable)
#define sched_max_index() (SchedIndex)(2 - 1U)
#define sched_index_to_taskid(sched_index) (TaskId)(sched_index)
#define sched_taskid_to_index(task_id) (SchedIndex)(task_id)
#define SCHED_OBJ(task_id) sched_tasks.tasks[task_id]
#define _signal_peek(cur_task_signals, mask) ((*(cur_task_signals) & (mask)) != 0)
#define SIGNAL_OBJ(task_id) signal_tasks.tasks[task_id]




static void
_yield(void)
{
    /* pre-condition: preemption disabled */
    TaskId to = irq_event_get_next();
    TaskId from = get_current_task();
    current_task = to;
    context_switch(get_task_context(from), get_task_context(to));
    /* post-condition: preemption disabled */
}

static void
_block(void)
{
    /* pre-condition: preemption disabled */
    sched_set_blocked(get_current_task());
    _yield();
    /* post-condition: preemption disabled */
}

static void
_block_on(TaskId t)
{
    /* pre-condition: preemption disabled */
    sched_set_blocked_on(get_current_task(), t);
    _yield();
    /* post-condition: preemption disabled */
}

static void
_unblock(TaskId task)
{
    /* pre-condition: preemption disabled */
    sched_set_runnable(task);
    /* Note: Must yield here as the task being unblocked may have an effective
       priority higher than the current task */
    _yield();
    /* post-condition: preemption disabled */
}

static void
handle_irq_event(IrqEventId irq_event_id)
{
    /* pre-condition: preemption disabled */
    TaskId task = irq_events[irq_event_id].task;
    SignalSet sig_set = irq_events[irq_event_id].sig_set;

    rtos_signal_send_set(task, sig_set);
    /* post-condition: preemption disabled */
}

static void
_preempt_enable(void)
{
    /* FIXME: This should be done atomically. I.e.: with interrupts disabled */
    bool pending = exception_preempt_pending;
    if (!pending)
    {
        exception_preempt_disabled = 0;
    }

    if (pending)
    {
        _yield();
    }
}

static void
context_init(context_t *const ctx, void (*const fn)(void), uint32_t *const stack_base, const size_t stack_size)
{
    uint32_t *context;
    context = stack_base + stack_size - CONTEXT_SIZE;
    context[CONTEXT_V1_IDX] = (uint32_t) fn;
    context[CONTEXT_PC_IDX] = (uint32_t) armv7m_trampoline;
    *ctx = context;
}
static void
sched_set_runnable(const TaskId task_id)
{
    SCHED_OBJ(task_id).blocked_on = task_id;
}

static void
sched_set_blocked(const TaskId task_id)
{
    SCHED_OBJ(task_id).blocked_on = TASK_ID_NONE;
}

static void
sched_set_blocked_on(const TaskId task_id, const TaskId blocker)
{
    SCHED_OBJ(task_id).blocked_on = blocker;
}

static TaskIdOption
sched_get_next(void)
{
    /* NOTE: In the case where assume_runnable is true and no runnable
       tasks are found, then an undefined task will be returned from this
       function.
    */
    TaskIdOption task, next_task;
    SchedIndex idx;

    for (idx = SCHED_INDEX_ZERO; idx <= sched_max_index(); idx++)
    {
        task = sched_index_to_taskid(idx);
        do
        {
            next_task = SCHED_OBJ(task).blocked_on;
            if (next_task == task)
            {
                goto found;
            }
            task = next_task;
        }
        while (task != TASK_ID_NONE);
    }
found:
    return  task;
}
static SignalId
_signal_recv(SignalSet *const cur_task_signals, const SignalSet mask)
{
    SignalSet signal_mask, signal_inverse;
    SignalId signal;

    signal_mask = *cur_task_signals & mask;

    signal_inverse = 1U;
    signal = 0;

    while ((signal_mask & 1U) == 0)
    {
        signal_mask >>= 1;
        signal_inverse <<= 1;
        signal++;
    }

    *cur_task_signals = *cur_task_signals & ~signal_inverse;

    return signal;
}
static void
irq_event_process(void)
{
    uint32_t tmp = irq_event;
    while (tmp != 0)
    {
        IrqEventId i = __builtin_ffs(tmp) - 1;
        irq_event_bitband[i] = 0;
        handle_irq_event(i);
        tmp &= ~(1U << i);
    }
}

static inline bool
irq_event_check(void)
{
    return irq_event != 0;
}

static inline void
irq_event_wait(void)
{
    asm volatile("cpsid i");
    asm volatile("isb");
    if (!irq_event_check())
    {
        asm volatile("wfi");
    }
    asm volatile("cpsie i");
}
static TaskId
irq_event_get_next(void)
{
    TaskIdOption next;

    for (;;)
    {
        irq_event_process();
        next = sched_get_next();
        if (next == TASK_ID_NONE)
        {
            irq_event_wait();
        }
        else
        {
            break;
        }
    }

    return next;
}
static void
mutex_init(void)
{
    TaskId t;
    MutexId m;

    for (t = TASK_ID_ZERO; t <= TASK_ID_MAX; t++)
    {
        waiters[t] = MUTEX_ID_NONE;
    }

    for (m = MUTEX_ID_ZERO; m <= MUTEX_ID_MAX; m++)
    {
        mutexes[m].holder = TASK_ID_NONE;
    }
}
static void
sem_init(void)
{
    TaskId t;

    for (t = TASK_ID_ZERO; t <= TASK_ID_MAX; t++)
    {
        waiters[t] = SEM_ID_NONE;
    }
}

static bool
internal_sem_try_wait(const SemId s)
{
    /* Must be called with pre-emption disabled */
    if (semaphores[s].value == SEM_VALUE_ZERO)
    {
        return false;
    }
    else
    {
        semaphores[s].value--;
        return true;
    }
}
void
rtos_preempt_handler(void)
{
    _yield();
    _preempt_enable();
}

void
rtos_yield(void)
{
    /* pre-condition: preemption enabled */
    preempt_disable();
    _yield();
    preempt_enable();
    /* pre-condition: preemption enabled */
}

void
rtos_start(void)
{
    sem_init();
    mutex_init();

    context_init(get_task_context(0), fn_b, stack_0, 64);
    sched_set_runnable(0);
    context_init(get_task_context(1), fn_a, stack_1, 64);
    sched_set_runnable(1);

    context_switch_first(get_task_context(TASK_ID_ZERO));
}



SignalId
rtos_signal_wait_set(const SignalSet sig_set)
{
    SignalSet *const cur_task_signals = &SIGNAL_OBJ(get_current_task()).signals;
    SignalId r;

    preempt_disable();

    if (_signal_peek(cur_task_signals, sig_set))
    {
        rtos_yield();
    }
    else
    {
        do
        {
            _block();
        } while (!_signal_peek(cur_task_signals, sig_set));
    }

    r = _signal_recv(cur_task_signals, sig_set);

    preempt_enable();

    return r;
}

void
rtos_signal_send_set(const TaskId task_id, const SignalSet sig_set)
{
    preempt_disable();

    SIGNAL_OBJ(task_id).signals |= sig_set;
    _unblock(task_id);

    preempt_enable();
}

bool
rtos_signal_peek_set(SignalSet sig_set)
{
    SignalSet *const cur_task_signals = &SIGNAL_OBJ(get_current_task()).signals;

    return _signal_peek(cur_task_signals, sig_set);
}

SignalIdOption
rtos_signal_poll_set(SignalSet sig_set)
{
    SignalSet *const cur_task_signals = &SIGNAL_OBJ(get_current_task()).signals;
    SignalIdOption r = SIGNAL_ID_NONE;

    preempt_disable();

    if (_signal_peek(cur_task_signals, sig_set))
    {
        r = _signal_recv(cur_task_signals, sig_set);
    }

    preempt_enable();

    return r;
}
void
rtos_irq_event_raise(IrqEventId irq_event_id)
{
    irq_event_bitband[irq_event_id] = 1;
}

void
rtos_mutex_lock(const MutexId m)
{
    while (!rtos_mutex_try_lock(m))
    {
        waiters[get_current_task()] = m;
        _block_on(mutexes[m].holder);
    }
}

void
rtos_mutex_unlock(const MutexId m)
{
    TaskId t;

    for (t = TASK_ID_ZERO; t <= TASK_ID_MAX; t++)
    {
        if (waiters[t] == m)
        {
            waiters[t] = MUTEX_ID_NONE;
            _unblock(t);
        }
    }

    mutexes[m].holder = TASK_ID_NONE;
}

bool
rtos_mutex_try_lock(const MutexId m)
{
    if (mutexes[m].holder != TASK_ID_NONE)
    {
        return false;
    }
    else
    {
        mutexes[m].holder = get_current_task();
        return true;
    }
}
void
rtos_sem_wait(const SemId s)
{
    preempt_disable();

    while (!internal_sem_try_wait(s))
    {
        waiters[get_current_task()] = s;
        _block();
    }

    preempt_enable();
}

void
rtos_sem_post(const SemId s)
{
    TaskId t;

    preempt_disable();

    if (semaphores[s].value == SEM_VALUE_ZERO)
    {
        for (t = TASK_ID_ZERO; t <= TASK_ID_MAX; t++)
        {
            if (waiters[t] == s)
            {
                waiters[t] = SEM_ID_NONE;
                _unblock(t);
            }
        }
    }

    semaphores[s].value++;

    preempt_enable();
}

bool
rtos_sem_try_wait(const SemId s)
{
    bool r;

    preempt_disable();
    r = internal_sem_try_wait(s);
    preempt_enable();

    return r;
}
