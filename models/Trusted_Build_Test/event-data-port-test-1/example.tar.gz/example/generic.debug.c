/*
Unpublished copyright (c) 2013 National ICT Australia (NICTA),
ABN 62 102 206 173.  All rights reserved.

The contents of this document are proprietary to NICTA and you may not
use, copy, modify, sublicense or distribute the contents in any form
except as permitted under the terms of a separately executed licence
agreement with NICTA.

COMMERCIAL LICENSE RIGHTS
Agreement No.: FA8750-12-9-0179
Contractor's Name; Rockwell Collins, Inc.
Contractor's Address: 400 Collins Road N.E., Cedar Rapids, IA 52498

By accepting delivery of the RTOS Code and Documentation, the Licensee
agrees that the software is "commercial" computer software within the
meaning of the applicable acquisition regulations (e.g., FAR 2.101 or
DFARS 227.7202-3).  The terms and conditions of this License shall pertain
to the Licensee's use and disclosure of the software, and shall supersede
any conflicting contractual terms or conditions.

*/
/*<module>
  <code_gen>template</code_gen>
  <headers>
      <header path="debug.h" code_gen="template" />
  </headers>
  <schema>
   <entry name="prefix" type="c_ident" default="" />
   <entry name="ll_debug" type="c_ident" default="" />
  </schema>
</module>*/

#include <stdint.h>
#include "debug.h"

extern void armv7m_semihost_debug_putc(char);

void
debug_print(const char *msg)
{
    while (*msg != 0)
    {
        armv7m_semihost_debug_putc(*msg);
        msg++;
    }
}


void
debug_println(const char *const msg)
{
    debug_print(msg);
    armv7m_semihost_debug_putc('\n');
}

static void
put_hexdigit(const uint8_t val)
{
    char ch;
    if (val < 10)
    {
        ch = '0' + val;
    }
    else
    {
        ch = ('a' - 10) + val;
    }
    armv7m_semihost_debug_putc(ch);
}

void
debug_printhex32(const uint32_t val)
{
    armv7m_semihost_debug_putc('0');
    armv7m_semihost_debug_putc('x');

    put_hexdigit((val >> 28) & 0xf);
    put_hexdigit((val >> 24) & 0xf);
    put_hexdigit((val >> 20) & 0xf);
    put_hexdigit((val >> 16) & 0xf);
    put_hexdigit((val >> 12) & 0xf);
    put_hexdigit((val >> 8) & 0xf);
    put_hexdigit((val >> 4) & 0xf);
    put_hexdigit((val >> 0) & 0xf);
}
