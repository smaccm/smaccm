#/bin/sh
arm-none-eabi-gdb ./out/kochab-system/system
