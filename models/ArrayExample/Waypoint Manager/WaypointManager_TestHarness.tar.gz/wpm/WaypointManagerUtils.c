/*
 * Author: Dan DaCosta
 * Company: Rockwell Collins
 * License: Air Force Open Source Agreement Version 1.0
 *   
 */
#include "WaypointManagerUtils.h"
#include <stdbool.h>

Waypoint * FindWaypoint(const Waypoint * ws,
                        const uint16_t len,
                        const int64_t id) {
  for(uint16_t i = 0 ; i < len; i++) {
    if(ws[i].number == id) {
     return ws + i;
    }
  }
  return NULL;
}

/* NB: Cycles in ws will be unrolled into win. */
bool FillWindow(  Waypoint * ws
                  , uint16_t len_ws
                  , int64_t id
                  , uint16_t len_ws_win
                  , Waypoint * ws_win /* out */) {
  uint16_t i;
  int64_t nid = id;
  Waypoint * wp = NULL;
  bool success = true;
  for(i=0; i < len_ws_win && success == true; i++) {
    success = false;
    wp = FindWaypoint(ws, len_ws, nid);
    if(wp != NULL) {
      success = true;
      ws_win[i] = *wp;
      nid = ws_win[i].nextwaypoint;
    }
  }
  return success;
}

void GroomWindow(uint16_t len_ws_win
                , Waypoint * ws_win /* out */) {
  ws_win[len_ws_win-1].nextwaypoint = ws_win[len_ws_win-1].number;
  return;
}

/* ASM: ws != null */
/* ASM: len_ws > 0. */
/* ASM: ws_win != null */
/* ASM: len_ws_win > 0 */
/* ASM: len_ws_win is less than the number of waypoints that can be
   stored in ws_win. */
/* ASM: Last waypoint starts a cycle. */
bool AutoPilotMissionCommandSegment(  Waypoint * ws
                                      , uint16_t len_ws
                                      , int64_t id
                                      , Waypoint * ws_win /* out */
                                      , uint16_t len_ws_win) {
  bool success = false;
  success = FillWindow(ws, len_ws, id, len_ws_win, ws_win);
  if(success == true) {GroomWindow(len_ws_win, ws_win);}
  return success;
}

#ifdef __WAYPOINTMANAGERUTILS_TEST__
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "./CMASI/MissionCommand.h"

int lmcp_process_msg(uint8_t** inb, size_t size, lmcp_object **o);
int lmcp_unpack(uint8_t** inb, size_t size, lmcp_object **o);


#define DEBUG(fmt,args...) \
  printf("%s,%s,%i:"fmt,__FUNCTION__,"MissionCommandMtils.c",__LINE__,##args)


#define RETURNONFAIL(X)                                 \
  if((X) != true) {                                     \
    printf("(%s:%u) Test failed.\n",__FILE__,__LINE__); \
    return false;                                       \
  }

#define TEST(X)                                             \
  {                                                         \
    bool flag;                                              \
    printf("%s ",#X);                                       \
    flag = X();                                             \
    printf("%s\n", flag == true ? " Passed." : " Failed."); \
  }

/* missioncommandFromFile: Deserialize a mission command reading from a
   file.

     f - The file to read the mission command from.

     mcp - The mission command to be populated from the serialized data.

*/
void missioncommandFromFile(FILE * f, MissionCommand ** mcpp) {

    uint8_t * source = NULL;
    uint8_t * orig_source = NULL;

    size_t size = 0;

    /* assumption: mcpp is not NULL. */
    assert(mcpp != NULL);
    /* assumption: f is not NULL. */
    assert(f != NULL);

    if (fseek(f, 0L, SEEK_END) == 0) {
        /* Get the size of the file. */
        size = ftell(f);
        if (size == -1) {
            /* Error */
        }

        /* Allocate our buffer to that size. */
        source = malloc(sizeof(char) * (size + 1));
        orig_source = source;
        /* Go back to the start of the file. */
        if (fseek(f, 0L, SEEK_SET) != 0) {
            /* Error */
        }

        /* Read the entire file into memory. */
        size_t newlen = fread(source, sizeof(char), size, f);
        if ( ferror( f ) != 0 ) {
            fputs("Error reading file", stderr);
        } else {
            source[newlen++] = '\0'; /* Just to be safe. */
        }

        assert(lmcp_process_msg(&source,size,(lmcp_object**)mcpp) != -1);
        //lmcp_pp(*mcpp);
        free(orig_source);
        source = NULL;
        orig_source = NULL;
    }


    return;
}

bool Test(MissionCommand * omcp) {
  Waypoint * wp = NULL;
  Waypoint * ws = NULL;
  Waypoint * ws_seg = NULL;
  uint16_t ws_len = 0;
  /* Convert the mission command into an array of waypoints. */
  ws_len = omcp->waypointlist_ai.length;
  ws = calloc(sizeof(Waypoint),ws_len);
  for(uint16_t i = 0; i < ws_len; i++) {
    ws[i] = *(omcp->waypointlist[i]);
  }
  
  uint16_t i = 6;
  uint16_t j = 1;
  int64_t last_subseq_id = omcp->firstwaypoint;
  ws_seg = calloc(sizeof(Waypoint),i);        

  last_subseq_id = omcp->firstwaypoint;
  wp = FindWaypoint(ws,ws_len,last_subseq_id);
  RETURNONFAIL(wp != NULL);
  RETURNONFAIL(AutoPilotMissionCommandSegment(ws,
                                              ws_len,
                                              wp->number,
                                              ws_seg,
                                              i) == true);      

  for(uint16_t k = 0 ; k < j ; k++) {
    wp = FindWaypoint(ws,ws_len,wp->nextwaypoint);
    RETURNONFAIL(wp != NULL);
  }
  while(wp->number != wp->nextwaypoint) {
    RETURNONFAIL(AutoPilotMissionCommandSegment(ws,
                                                ws_len,
                                                wp->number,
                                                ws_seg,
                                                i) == true);
    for(uint16_t k = 0 ; k < j ; k++) {
      wp = FindWaypoint(ws, ws_len,wp->nextwaypoint);
      RETURNONFAIL(wp != NULL);
    }
  }
  free(ws_seg);
  ws_seg = NULL;
  free(ws);
  return true;
}

int main(void) {

    FILE * f = NULL;
    MissionCommand * omcp = NULL;
    lmcp_init_MissionCommand(&omcp);
    /* Load waterways data. */
    f = fopen("./testdata/waterways.mc","r");
    RETURNONFAIL(f != NULL);
    missioncommandFromFile(f, &omcp);
    fclose(f);
    Test(omcp);
    lmcp_free((lmcp_object*)omcp);
    return 0;
}

#endif /* __WAYPOINTMANAGERUTILS_TEST__ */
